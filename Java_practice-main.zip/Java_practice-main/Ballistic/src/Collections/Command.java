package Collections;

public interface Command {

    /** Выполнение команды; шаблоны: Command, Worker Thread */
    public void execute();

}

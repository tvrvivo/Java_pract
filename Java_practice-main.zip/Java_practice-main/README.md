# Java practice
Group №35

Student: Artem Teslia
